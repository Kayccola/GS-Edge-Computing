#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

// Inicializa o display OLED usando o barramento padrão I2C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

const int pinoPotenciometro = A0; // Entrada analógica para o sensor simulado
const int buzzer = 11;            // Saída digital para o alerta sonoro

void setup() {
  Serial.begin(9600);
  pinMode(buzzer, OUTPUT);

  // Inicializa o display no endereço I2C padrão 0x3C
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
    Serial.println(F("Erro: Display OLED nao encontrado!"));
    for(;;); 
  }
  
  // Inicialização visual do ORBIT MIND
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(30, 20);
  display.println("ORBIT MIND");
  display.setCursor(20, 40);
  display.println("Inicializando...");
  display.display();
  delay(2000);
}

void loop() {
  // Lê o valor do potenciômetro (0 a 1023)
  int leitura = analogRead(pinoPotenciometro);
  
  // Mapeia o valor lido para uma escala percentual de fadiga (0 a 100%)
  int nivelEstresse = map(leitura, 0, 1023, 0, 100);

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  
  display.setCursor(15, 0);
  display.println("--- ORBIT MIND ---");
  
  display.setCursor(0, 22);
  display.setTextSize(2);
  display.print("Fadiga: ");
  display.print(nivelEstresse);
  display.println("%");

  display.setTextSize(1);
  display.setCursor(0, 52);

  // Lógica de monitoramento preventivo baseado na Global Solution
  if (nivelEstresse < 75) {
    display.println("Status: Operacao Segura"); 
    noTone(buzzer);
  } else {
    display.println("ALERTA: RISCO BURNOUT"); 
    
    // Emite o alerta sonoro intermitente de segurança
    tone(buzzer, 1000); 
    delay(150);
    noTone(buzzer);
  }

  display.display();
  delay(200); 
}